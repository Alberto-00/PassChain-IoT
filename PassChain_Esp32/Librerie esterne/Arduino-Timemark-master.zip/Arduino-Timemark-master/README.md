# Arduino-Timemark

This library provides a Timemark abstraction of the classical "Blink-without-delay" pattern. Please see the example sketches for typical usage (button debounce, timeouts, multiple blink, etc).

## Install

Download and unzip the Arduino-Timemark library into your sketchbook
libraries directory. Rename from Arduino-Timemark-master to Arduino-Timemark.

The Timemark library and examples should be found in the Arduino IDE
File>Examples menu.

